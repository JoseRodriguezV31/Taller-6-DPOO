package uniandes.dpoo.swing.interfaz.principal;

import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import uniandes.dpoo.swing.mundo.Restaurante;

@SuppressWarnings("serial")
public class PanelDetallesRestaurante extends JPanel
{
    private JLabel labNombre;
    private JLabel labCalificacion;
    private JCheckBox chkVisitado;

    public PanelDetallesRestaurante()
    {
        setLayout(new GridLayout(3, 1, 5, 5)); // 3 filas, 1 columna, con espaciado

        // Configura la etiqueta para el nombre
        labNombre = new JLabel("Nombre: ");
        add(labNombre);

        // Configura la etiqueta para la calificación
        labCalificacion = new JLabel();
        add(labCalificacion);

        // Configura el checkbox para visitado
        chkVisitado = new JCheckBox("Visitado");
        chkVisitado.setEnabled(false); // Para que sea solo de visualización
        add(chkVisitado);
    }

    /**
     * Actualiza los datos mostrados del restaurante
     */
    private void actualizarRestaurante(String nombre, int calificacion, boolean visitado)
    {
        labNombre.setText("Nombre: " + (nombre != null ? nombre : ""));
        labCalificacion.setIcon(buscarIconoCalificacion(calificacion));
        chkVisitado.setSelected(visitado);
    }

    /**
     * Actualiza los datos que se muestran de un restaurante
     */
    public void actualizarRestaurante(Restaurante r)
    {
        if(r != null) {
            this.actualizarRestaurante(r.getNombre(), r.getCalificacion(), r.isVisitado());
        } else {
            this.actualizarRestaurante("", 0, false); // Valores por defecto para null
        }
    }

    /**
     * Obtiene el icono de calificación correspondiente
     */
    private ImageIcon buscarIconoCalificacion(int calificacion)
    {
        String imagen = "./imagenes/stars" + Math.max(1, Math.min(5, calificacion)) + ".png";
        return new ImageIcon(imagen);
    }
}